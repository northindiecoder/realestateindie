
<!DOCTYPE html>
<html dir="ltr" lang="ru" class="has-hover no-js">
<head>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-TWR83TH');</script>
    <!-- End Google Tag Manager -->
    
            <meta charset="utf-8">
        <meta name="Author" content=""/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

                <title>Страница не найдена | ЖК ПОКЛОННАЯ 9</title>
        <meta name="description" content=""/>

                        <link rel="shortcut icon" href="/favicon-ru.ico?v=1707986906"/>
        
                  <link rel="alternate" href="https://p9.moscow/signals/iwl.js" hreflang="ru" />
      <link rel="alternate" href="https://p9.moscow/en/signals/iwl.js" hreflang="en" />

            <link rel="icon" type="image/png" sizes="32x32" href="/assets/manifest/favicon-32x32.png?v=1707986906" />
        <link rel="icon" type="image/png" sizes="16x16" href="/assets/manifest/favicon-16x16.png?v=1707986906" />
        <link rel="apple-touch-icon" href="/assets/manifest/apple-touch-icon.png?v=1707986906" />
        <link rel="mask-icon" href="/assets/manifest/safari-pinned-tab.svg?v=1707986906" color="#ffffff" />

        <link rel="manifest" href="/assets/manifest/manifest.webmanifest?v=1707986906" />
        <meta name="theme-color" content="#000000" />
        <meta name="msapplication-config" content="/assets/manifest/browserconfig.xml?v=1707986906" />

                            <meta property="og:type" content="website" />
        <meta property="og:url" content="https://p9.moscow" />
        <meta property="og:title" content="Страница не найдена | ЖК ПОКЛОННАЯ 9" />
        <meta property="og:description" content="" />
        <meta property="og:image" content="https://p9.moscow/assets/manifest/og.png" />

            <meta name="keywords" content=""/>
        <meta name="format-detection" content="telephone=no"/>

            <script>
            document.documentElement.classList.remove('no-js');
            document.documentElement.classList.add('js');

            if (document.documentElement.style.setProperty) {
                document.documentElement.style.setProperty('--viewport-height', window.innerHeight + 'px');
                document.documentElement.style.setProperty('--viewport-height-actual', window.innerHeight + 'px');
            }
            if (navigator.platform.toUpperCase().indexOf('WIN') >= 0) {
                document.documentElement.classList.add('is-win');
            }
        </script>

        <script type="text/javascript">
            document.addEventListener("DOMContentLoaded", function(event) {
            setTimeout(function() {
            ym(55556449,'reachGoal','time_left'); return true; }, 40000)
            });
        </script>

            <link rel="stylesheet" href="/assets/stylesheets/global.css?v=1707986906" />

                
                <link rel="dns-prefetch" href="https://storage.googleapis.com">
        <link rel="preconnect" href="https://storage.googleapis.com" crossorigin>

                
                <link rel="stylesheet" href="/assets/stylesheets/404.css?v=1707986906" />

                <script  async src="https://www.googletagmanager.com/gtag/js?id=UA-149029267-1"></script>
    <script >
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-149029267-1');
    </script>
                    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', 306666490669684);
        fbq('track', 'PageView');
    </script>
    <noscript>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=306666490669684&ev=PageView&noscript=1"/>
    </noscript>
    <!-- End Facebook Pixel Code -->
        <!-- calltouch -->
<script type="text/javascript">
    (function(w,d,n,c){w.CalltouchDataObject=n;w[n]=function(){w[n]["callbacks"].push(arguments)};if(!w[n]["callbacks"]){w[n]["callbacks"]=[]}w[n]["loaded"]=false;if(typeof c!=="object"){c=[c]}w[n]["counters"]=c;for(var i=0;i<c.length;i+=1){p(c[i])}function p(cId){var a=d.getElementsByTagName("script")[0],s=d.createElement("script"),i=function(){a.parentNode.insertBefore(s,a)};s.type="text/javascript";s.async=true;s.src="https://mod.calltouch.ru/init.js?id="+cId;if(w.opera=="[object Opera]"){d.addEventListener("DOMContentLoaded",i,false)}else{i()}}})(window,document,"ct","v4z10e7m");
</script>
<!-- calltouch -->
            <meta name="ahrefs-site-verification" content="52843142ff9cc6db36770c8227d68184f4ce0c094da6c3a71428f3bf02deb218">
        <meta name="yandex-verification" content="f6a82d50053591db" />
</head>
<body data-barba="wrapper">
    <!-- Google Tag Manager (noscript) -->
    <noscript><div src="https://www.googletagmanager.com/ns.html?id=GTM-TWR83TH" 
    height="0" width="0" style="display:none;visibility:hidden"></div></noscript>
    <!-- End Google Tag Manager (noscript) -->
    
            <script type="text/javascript">
        (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
        m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
        (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

        ym('55556449', "init", {
            clickmap: true,
            trackLinks: true,
            accurateTrackBounce: true,
            webvisor: true
        });
    </script>

        
            
    <div
        role="dialog" aria-live="polite" aria-label="Cookie consent" aria-describedby="cookie-consent-description"
        class="cookie-consent ui-dark ui-dark-background"
        data-plugin="cookieConsent theme"
        id="cookie-consent"
    >
        <p id="cookie-consent-description" class="text--c4-mob pb-0.5 pb-0:md">
            Мы используем cookie для того, чтобы предоставить Вам больше возможностей при использовании сайта.
            <a aria-label="Learn more about cookies" tabindex="0" href="/privacy-policy" class="text--color-primary ">Подробнее</a>
        </p>
        <div class="group group--nowrap">
                    
                                                                    
            
    <a
        class="btn btn--tetriary btn--xsm btn--outline js-cookie-consent-accept"
                                                                                                                    aria-label="Accept use of cookies"
                                                    tabindex="0"
                            role="button"
            >
        <span class="btn__content">
                            <span class="btn__text text--c4-mob">хорошо</span>
                                </span>
    </a>

        </div>
    </div>

        <script>
        if (document.cookie.indexOf('cookieConsentStatus=1') !== -1) {
            document.querySelector('#cookie-consent').className += ' is-hidden';
        }
    </script>
    
        <div
        class="page-content-wrapper js-page-content-wrapper ui-light-background"
        data-barba="container" data-barba-namespace="page"

                    >
                                    

<aside
    class="menu-dropdown is-hidden--sm-down is-hidden"
    role="dialog"
    aria-hidden="true"
    id="menu-apartments"
    data-plugin="dropdownmenu"
    data-dropdownmenu-header-class-name=".header.header--sticky .header__content"
>
    <div class="menu-dropdown__backdrop"></div>
    <div class="menu-dropdown__animation">
        <div class="menu-dropdown__animation-inner js-menu-content">
            <div class="menu-dropdown__content ui-dark ui-background">
                <div class="row menu-dropdown__content-row">
                    <div class="col col--md-6 menu-dropdown__left">
                        <a class="card card--dropdown animation--image-hover btn-container" 
                            href="/apartments-visual"
                        >
                            
                
    
    
    <picture class="is-invisible--js is-hidden--no-js ui-dark ui-background card__background"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221080%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201080%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221080%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201080%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20420%22%3E%3C/svg%3E"                    alt="image of building"                            width="720" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" ui-dark ui-background card__background"            draggable="false"    >
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.webp?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906"                    alt="image of building"                            width="720" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                                    
                                                                    
            
    <span
        class="btn btn--inverse btn--md btn--square btn--zoom card__button is-hidden--sm-down is-decorative"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-arrow-right btn__icon " width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#arrow-right" xlink:href="/assets/images/icons.svg?v=1707986906#arrow-right"></use></svg>
                    </span>
    </span>

                            <p class="card__lb h3 leading-trim text--color-text">
                                визуальный<br />
 выбор
                            </p>
                        </a>
                    </div>
                    <div class="col col--md-6 menu-dropdown__right">
                        <a class="card card--dropdown animation--image-hover btn-container" 
                            href="/apartments"
                        >
                            
                
    
    
    <picture class="is-invisible--js is-hidden--no-js card__background"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221446%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201446%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.png?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221446%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201446%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221085%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201085%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxl.png?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221085%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201085%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22724%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20724%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22724%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20724%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22724%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20724%20420%22%3E%3C/svg%3E"                    alt="decorative image"                            width="724" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" card__background"            draggable="false"    >
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.webp?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.png?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxl.png?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906"                    alt="decorative image"                            width="724" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                                    
                                                                    
            
    <span
        class="btn btn--primary btn--outline btn--md btn--square card__button is-hidden--sm-down is-decorative"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-arrow-right btn__icon " width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#arrow-right" xlink:href="/assets/images/icons.svg?v=1707986906#arrow-right"></use></svg>
                    </span>
    </span>

                            <p class="card__lb h3 leading-trim text--color-text">
                                выбор<br />
 по параметрам
                            </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</aside>
            
            



    

<header
    class="header header--sticky is-hidden--print js-header is-decorative ui-dark"
            data-plugin="stickyHeader"
        data-sticky-header-hide-on-scroll="false"
                    >
    <div class="header__content ">
        <div class="container-h">

            <div class="row row--middle-xs is-not-decorative">
                                <div class="col col--md-4 is-hidden--sm-down">
                    <div class="group group--nowrap group--middle">
                                                        
                                                                    
            
    <a
        class="btn btn--link btn--with-icon-text btn--icon-left btn--sm"
                                                href="#menu"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">Меню</span>
                                        <svg class="icon icon-menu btn__icon " width="40" height="8" aria-hidden="true"            viewBox="0 0 40 8"
            style="--icon-width: 40; --icon-height: 8;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#menu" xlink:href="/assets/images/icons.svg?v=1707986906#menu"></use></svg>
                    </span>
    </a>

                        
                        <div class="header__apartments">
                                                                                                
                                                                    
            
    <a
        class="btn btn--tetriary btn--sm btn--outline"
                                                                                                                                                
                                    data-menu-trigger="#menu-apartments"
                                    data-menu-disabled-href="/apartments"
                            tabindex="0"
                            role="button"
            >
        <span class="btn__content">
                            <span class="btn__text ">Выбрать апартаменты</span>
                                </span>
    </a>

                                                        
                            <div class="tag-button js-favourite-counter-parent ui-light">
                                        
                                                                    
            
    <a
        class="btn btn--primary btn--sm btn--square btn--favourites js-favourite-counter-button"
                                                href="#favourites"
                                                                                                    >
        <span class="btn__content">
                                        <svg class="icon icon-favourite-empty btn__icon " width="24" height="25" aria-hidden="true"            viewBox="0 0 24 25"
            style="--icon-width: 24; --icon-height: 25;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#favourite-empty" xlink:href="/assets/images/icons.svg?v=1707986906#favourite-empty"></use></svg>
                    </span>
    </a>

                                        
                                                                    
                        
    <span
        class="btn btn--primary is-hidden btn--square btn--xxs btn--favourites tag-button__count tag-button__count--inverse header__apartments__counter"
                                    data-plugin="favouriteCounter"

                                                    
                                    data-favourite-counter-method="GET"
                                    data-favourite-counter-url="/api/apartments/favourite"
                            >
        <span class="btn__content">
                            <span class="btn__text ">2</span>
                                </span>
    </span>

                            </div>
                        </div>
                    </div>
                </div>

                                                        <div class="col col--xs-1 is-hidden--md-up">
                                                        
                                                                    
            
    <a
        class="btn btn--link btn--sm"
                                                href="#menu"
                                                                    aria-label="Меню"
                                                    >
        <span class="btn__content">
                                        <svg class="icon icon-menu btn__icon " width="40" height="8" aria-hidden="true"            viewBox="0 0 40 8"
            style="--icon-width: 40; --icon-height: 8;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#menu" xlink:href="/assets/images/icons.svg?v=1707986906#menu"></use></svg>
                    </span>
    </a>

                    </div>

                                        <div class="col col--xs-3 col--md-4 js-header-logo">
                        <a href="/" class="header__logo error-logo" title="ПОКЛОННАЯ 9">
                                                            <svg class="icon icon-logo-header" width="95" height="8" aria-hidden="true"            viewBox="0 0 95 8"
            style="--icon-width: 95; --icon-height: 8;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#logo-header" xlink:href="/assets/images/icons.svg?v=1707986906#logo-header"></use></svg>
                                                    </a>
                    </div>
                                
                <div class="col col--xs-auto col--md-4">
                    <div class="group group--nowrap group--middle is-hidden--sm-down">
                        <a class="group__right" href="tel:+74993221667">
                            +7 499 322 16 67
                        </a>
                                
                                                                    
            
    <a
        class="btn btn--primary btn--sm btn--outline btn--text-right btn--halo"
                                                href="#callback"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">Заказать звонок</span>
                                </span>
    </a>

                    </div>
                    
                                                                <div class="header__mobile-expanded header__mobile-expanded--right is-hidden--md-up">
                                    
                                                                    
            
    <a
        class="btn btn--tetriary btn--xs btn--text-xs"
                                                href="/apartments"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">апартаменты</span>
                                </span>
    </a>

                        </div>
                        <div class="header__mobile-collapsed is-hidden--md-up js-favourite-couter-mobile-empty">
                                    
                                                                    
            
    <a
        class="btn btn--tetriary btn--xs btn--text-xs"
                                                href="/apartments"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">апартаменты</span>
                                </span>
    </a>

                        </div>

                        <div class="header__mobile-collapsed tag-button js-favourite-counter-parent is-hidden is-hidden--md-up">
                                    
                                                                    
            
    <a
        class="btn btn--tetriary btn--xs btn--text-xs js-favourite-counter-button"
                                                href="#favourites"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">избранное</span>
                                        <svg class="icon icon- btn__icon " width="10" height="10" aria-hidden="true"            viewBox="0 0 10 10"
            style="--icon-width: 10; --icon-height: 10;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#" xlink:href="/assets/images/icons.svg?v=1707986906#"></use></svg>
                    </span>
    </a>

                                    
                                                                    
                        
    <span
        class="btn is-hidden btn--square btn--xxs tag-button__count tag-button__count--inline header__apartments__counter"
                                    data-plugin="favouriteCounter"

                                                    
                                    data-favourite-counter-method="GET"
                                    data-favourite-counter-url="/api/apartments/favourite"
                                                        data-favourite-counter-hide-is-empty="true"
                                    data-favourite-counter-toggle-class="js-favourite-couter-mobile-empty"
                            >
        <span class="btn__content">
                            <span class="btn__text ">2</span>
                                </span>
    </span>

                        </div>
                                    </div>
            </div>

        </div>
    </div>
</header>
        
                                <div class="page-content js-page-content">
                <main>
                        <section
        class="section section--no-overflow ui-dark ui-background"
        data-scroll-section
    >
        <div class="container-h">
            <div class="row">
                <div class="col col--center text--center">
                    <div class="error-page">
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js error-page__image"                data-plugin="appear  parallaxDeco"        draggable="false"    >
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-xxxl.webp?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-xxxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-lg.webp?v=1707986906?v=1707986906" media="(min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-lg.jpg?v=1707986906?v=1707986906" media="(min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-xs.webp?v=1707986906?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/404/error-xs.jpg?v=1707986906?v=1707986906" type="image/jpeg"/>
        <img
            data-src="/assets/images/404/error-xs.jpg?v=1707986906?v=1707986906"
                src="/assets/images/px.gif?v=1707986906"                    alt=""                        draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" error-page__image"                data-plugin=" parallaxDeco"        draggable="false"    >
                                <source srcset="/assets/images/404/error-xxxl.webp?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/404/error-xxxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/404/error-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/404/error-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/404/error-lg.webp?v=1707986906?v=1707986906" media="(min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/404/error-lg.jpg?v=1707986906?v=1707986906" media="(min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/404/error-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/404/error-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/404/error-xs.webp?v=1707986906?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/404/error-xs.jpg?v=1707986906?v=1707986906" type="image/jpeg"/>
        <img
                                src="/assets/images/404/error-xs.jpg?v=1707986906?v=1707986906"                    alt=""                        draggable="false"
            />
    </picture>

            
        </noscript>
    

                        <h1 class="error-page__title">
                            Страница
 не найдена
                        </h1>
                        <a href="/" class="btn-container">
                            <p class="text--c3 text--color-text text--crop error-page__link-text">
                                Перейти
 на главную
                            </p>

                                    
                                                                    
            
    <span
        class="btn btn--tetriary btn--square btn--sm-md btn--outline error-page__link-btn"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-arrow-right btn__icon " width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#arrow-right" xlink:href="/assets/images/icons.svg?v=1707986906#arrow-right"></use></svg>
                    </span>
    </span>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
                </main>

                            </div>
        
                <div class="js-modal">
                            



            
                            
        
    
    <div
        class="modal ui-dark modal--full is-hidden"
        role="dialog"
        id="menu"
        aria-hidden="true"        aria-label="Модальное меню"
            
                                    data-plugin="modal"
                                    data-modal-animation-name-in="modal-menu-in"
    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close">

                                        
                                        
    



    

<aside
    class="menu-dropdown is-hidden--sm-down is-hidden"
    role="dialog"
    aria-hidden="true"
    id="menu-apartments-modal"
    data-plugin="dropdownmenu"
    data-dropdownmenu-header-class-name=".header.header--modal .header__content"
>
    <div class="menu-dropdown__backdrop"></div>
    <div class="menu-dropdown__animation">
        <div class="menu-dropdown__animation-inner js-menu-content">
            <div class="menu-dropdown__content ui-dark ui-background">
                <div class="row menu-dropdown__content-row">
                    <div class="col col--md-6 menu-dropdown__left">
                        <a class="card card--dropdown animation--image-hover btn-container" 
                            href="/apartments-visual"
                        >
                            
                
    
    
    <picture class="is-invisible--js is-hidden--no-js ui-dark ui-background card__background"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221440%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201440%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221080%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201080%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221080%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201080%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20420%22%3E%3C/svg%3E"                    alt="image of building"                            width="720" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" ui-dark ui-background card__background"            draggable="false"    >
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.webp?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/dropdown-menu/image-1-md.jpg?v=1707986906?v=1707986906"                    alt="image of building"                            width="720" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                                    
                                                                    
            
    <span
        class="btn btn--inverse btn--md btn--square btn--zoom card__button is-hidden--sm-down is-decorative"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-arrow-right btn__icon " width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#arrow-right" xlink:href="/assets/images/icons.svg?v=1707986906#arrow-right"></use></svg>
                    </span>
    </span>

                            <p class="card__lb h3 leading-trim text--color-text">
                                визуальный<br />
 выбор
                            </p>
                        </a>
                    </div>
                    <div class="col col--md-6 menu-dropdown__right">
                        <a class="card card--dropdown animation--image-hover btn-container" 
                            href="/apartments"
                        >
                            
                
    
    
    <picture class="is-invisible--js is-hidden--no-js card__background"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221446%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201446%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.png?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221446%22%20height=%22840%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201446%20840%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221085%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201085%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-xxl.png?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221085%22%20height=%22630%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201085%20630%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22724%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20724%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22724%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20724%20420%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22724%22%20height=%22420%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20724%20420%22%3E%3C/svg%3E"                    alt="decorative image"                            width="724" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" card__background"            draggable="false"    >
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.webp?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxxl.png?v=1707986906?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-xxl.png?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/dropdown-menu/image-2-md.png?v=1707986906?v=1707986906"                    alt="decorative image"                            width="724" height="420"                    
                                    class="animation--image-hover__image"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                                    
                                                                    
            
    <span
        class="btn btn--primary btn--outline btn--md btn--square card__button is-hidden--sm-down is-decorative"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-arrow-right btn__icon " width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#arrow-right" xlink:href="/assets/images/icons.svg?v=1707986906#arrow-right"></use></svg>
                    </span>
    </span>

                            <p class="card__lb h3 leading-trim text--color-text">
                                выбор<br />
 по параметрам
                            </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</aside>

<header
    class="header header--modal is-hidden--print js-header is-decorative ui-dark"
>
    <div class="header__content">
        <div class="container-h-desktop">

            <div class="row row--middle-xs is-not-decorative">
                                <div class="col col--md-4 is-hidden--sm-down">
                    <div class="group group--nowrap group--middle">
                                                        
                                                                    
            
    <a
        class="btn btn--link btn--with-icon-text btn--icon-left btn--sm btn--text-invisible js-modal-close"
                                                                                                                                                    tabindex="0"
                            role="button"
            >
        <span class="btn__content">
                            <span class="btn__text ">Меню</span>
                                        <svg class="icon icon-close btn__icon " width="40" height="40" aria-hidden="true"            viewBox="0 0 40 40"
            style="--icon-width: 40; --icon-height: 40;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#close" xlink:href="/assets/images/icons.svg?v=1707986906#close"></use></svg>
                    </span>
    </a>


                                                <div class="header__apartments">
                                                                    
                                                                    
            
    <a
        class="btn btn--tetriary btn--sm btn--outline"
                                                href="/apartments"
                                                                                                
                                    data-menu-trigger="#menu-apartments"
                            >
        <span class="btn__content">
                            <span class="btn__text ">Выбрать апартаменты</span>
                                </span>
    </a>

                            
                            <div class="tag-button js-favourite-counter-parent">
                                        
                                                                    
            
    <a
        class="btn btn--primary btn--outline-- btn--sm btn--square btn--favourites js-favourite-counter-button"
                                                href="#favourites"
                                                                                                    >
        <span class="btn__content">
                                        <svg class="icon icon-favourite-empty btn__icon " width="24" height="25" aria-hidden="true"            viewBox="0 0 24 25"
            style="--icon-width: 24; --icon-height: 25;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#favourite-empty" xlink:href="/assets/images/icons.svg?v=1707986906#favourite-empty"></use></svg>
                    </span>
    </a>

                                        
                                                                    
                        
    <span
        class="btn btn--primary is-hidden btn--square btn--xxs btn--favourites tag-button__count tag-button__count--inverse header__apartments__counter"
                                    data-plugin="favouriteCounter"

                                                    
                                    data-favourite-counter-method="GET"
                                    data-favourite-counter-url="/api/apartments/favourite"
                            >
        <span class="btn__content">
                            <span class="btn__text ">2</span>
                                </span>
    </span>

                            </div>
                        </div>
                    </div>
                </div>

                                <div class="col col--xs-auto is-hidden--md-up">
                                                
                                                                    
            
    <a
        class="btn btn--link btn--sm js-modal-close"
                                                                                                                                                    tabindex="0"
                            role="button"
            >
        <span class="btn__content">
                                        <svg class="icon icon-close btn__icon " width="60" height="60" aria-hidden="true"            viewBox="0 0 60 60"
            style="--icon-width: 60; --icon-height: 60;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#close" xlink:href="/assets/images/icons.svg?v=1707986906#close"></use></svg>
                    </span>
    </a>

                </div>

                                <div class="col col--xs-fill col--md-4 text--center js-header-logo">
                                            <a href="/" class="header__logo is-hidden--sm-down" title="ПОКЛОННАЯ 9">
                            <svg class="icon icon-logo-header" width="189" height="20" aria-hidden="true"            viewBox="0 0 189 20"
            style="--icon-width: 189; --icon-height: 20;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#logo-header" xlink:href="/assets/images/icons.svg?v=1707986906#logo-header"></use></svg>
                        </a>
                                    </div>

                                                                                <a class="btn btn--tetriary btn--outline btn--square btn--xs mr-0.5 is-hidden--md-up" href="/en/signals/iwl.js" data-ajax-page-ignore-prefetch="true" data-ajax-page-ignore="true">
                   <span class="btn__content">
                                                  <span class="text--c4">EN</span>
                                          </span>
               </a>

                                <div class="col col--xs-auto col--md-4 pr-1 pr-0:md">
                    <div class="group group--nowrap group--middle is-hidden--sm-down">
                        <a class="group__right js-calltouch-phone-number" href="tel:+74993221667">
                            +7 499 322 16 67
                        </a>

                                
                                                                    
            
    <a
        class="btn btn--primary btn--sm btn--outline btn--text-right btn--halo"
                                                href="#callback"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">Заказать звонок</span>
                                </span>
    </a>

                    </div>

                                                
                                                                    
            
    <a
        class="btn btn--primary btn--xs btn--text-xs is-hidden--md-up"
                                                href="/apartments"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">апартаменты</span>
                                </span>
    </a>

                </div>
            </div>
        </div>
    </div>
</header>

    <div class="menu-modal row row--pad"
        data-plugin="menu"
    >

                
                
    
    
    <picture class="is-invisible--js is-hidden--no-js is-decorative menu-modal__deco is-hidden--md-up"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/menu/deco-xs.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22249%22%20height=%22320%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20249%20320%22%3E%3C/svg%3E" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/deco-xs.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22249%22%20height=%22320%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20249%20320%22%3E%3C/svg%3E" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/deco-xs.png?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22249%22%20height=%22320%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20249%20320%22%3E%3C/svg%3E"                    alt=""                            width="249" height="320"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" is-decorative menu-modal__deco is-hidden--md-up"            draggable="false"    >
                                <source srcset="/assets/images/menu/deco-xs.webp?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/menu/deco-xs.png?v=1707986906" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/deco-xs.png?v=1707986906"                    alt=""                            width="249" height="320"            draggable="false"
            />
    </picture>

            
        </noscript>
    
        <div class="col col--xs-5 col--md-6 menu-modal__col">
            <nav class="menu-modal__nav">
                                                
                                                        
                        <ol
                            class="menu-modal__list menu-modal__list--1 "
                                                    >
                                                                                            <li
                                    class="js-menu-item  is-hidden--md-up "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="316"
                                                                    >
                                                                            <a href="/" class="menu-modal__item js-modal-close ">
                                            главная
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="382"
                                                                    >
                                                                            <a href="/infrastructure" class="menu-modal__item js-modal-close ">
                                            инфраструктура
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="448"
                                                                    >
                                                                            <a href="/design" class="menu-modal__item js-modal-close ">
                                            дизайн
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="514"
                                                                    >
                                                                            <a href="/location" class="menu-modal__item js-modal-close ">
                                            Расположение
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="580"
                                                                    >
                                                                            <a href="/gallery" class="menu-modal__item js-modal-close ">
                                            галерея
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="646"
                                                                    >
                                                                            <a href="/lifestyle" class="menu-modal__item js-modal-close ">
                                            стиль жизни
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="712"
                                                                    >
                                                                            <a href="/about" class="menu-modal__item js-modal-close ">
                                            о проекте
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="778"
                                                                    >
                                                                            <a href="/apartments" class="menu-modal__item js-modal-close is-hidden--md-up">
                                            апартаменты
                                        </a>
                                        <a href="/apartments" class="menu-modal__item js-modal-close is-hidden--sm-down">
                                            апартаменты
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="js-menu-item   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="844"
                                                                    >
                                                                            <a href="/penthouses" class="menu-modal__item js-modal-close ">
                                            Пентхаусы
                                        </a>
                                                                    </li>
                            
                                                    </ol>

                                                                                                        <div class="group group--between group--end group--nowrap menu-modal__group">
                    
                        <ol
                            class="menu-modal__list menu-modal__list--2 js-menu-item"
                                                                                                                            data-reveal-distance="0"
                                data-reveal-group
                                                    >
                                                                                            <li
                                    class="   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="910"
                                                                    >
                                                                            <a href="/progress" class="menu-modal__item js-modal-close ">
                                            Ход строительства
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="976"
                                                                    >
                                                                            <a href="/news" class="menu-modal__item js-modal-close ">
                                            Новости
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="1042"
                                                                    >
                                                                            <a href="/contacts" class="menu-modal__item js-modal-close ">
                                            Контакты
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="1108"
                                                                    >
                                                                            <a href="/documents" class="menu-modal__item js-modal-close ">
                                            Документы
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="1174"
                                                                    >
                                                                            <a href="/how-to-buy" class="menu-modal__item js-modal-close ">
                                            Условия покупки
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="   "
                                                                            data-reveal="slide-in-bottom slow"
                                        data-reveal-delay="1240"
                                                                    >
                                                                            <a href="/team" class="menu-modal__item js-modal-close ">
                                            Команда
                                        </a>
                                                                    </li>
                                                                                            <li
                                    class="   is-hidden--md-up"
                                                                                                        >
                                                                            <a href="/video" class="menu-modal__item js-modal-close ">
                                            Видео о проекте
                                        </a>
                                                                    </li>
                            
                                                            <li class="is-hidden--md-up mt-1.5">
                                    <div class="tag-button js-favourite-counter-parent js-favourite-couter-mobile-full">
                                                
                                                                    
            
    <a
        class="btn btn--tetriary btn--sm btn--square favourite favourite--active-- js-favourite-counter-button"
                                                href="#favourites"
                                                                                                    >
        <span class="btn__content">
                                        <svg class="icon icon-favourite btn__icon " width="24" height="25" aria-hidden="true"            viewBox="0 0 24 25"
            style="--icon-width: 24; --icon-height: 25;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#favourite" xlink:href="/assets/images/icons.svg?v=1707986906#favourite"></use></svg>
                    </span>
    </a>

                                                
                                                                    
                        
    <span
        class="btn btn--primary is-hidden btn--square btn--xxs tag-button__count tag-button__count--right header__apartments__counter"
                                    data-plugin="favouriteCounter"

                                                    
                                    data-favourite-counter-method="GET"
                                    data-favourite-counter-url="/api/apartments/favourite"
                                                        data-favourite-counter-invisible-is-empty="true"
                            >
        <span class="btn__content">
                            <span class="btn__text ">2</span>
                                </span>
    </span>

                                    </div>
                                </li>
                                                    </ol>

                                                    <div class="group group--lg group--end group--nowrap is-hidden--sm-down header-broshure">
                                <div>
                                    <div class="header__video-btn">
                                        <a class="btn-container group group--small group--middle group--nowrap " href="/video">
                                                    
                                                                    
            
    <span
        class="btn btn--tetriary btn--outline btn--square btn--sm"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-play-xs btn__icon " width="18" height="18" aria-hidden="true"            viewBox="0 0 18 18"
            style="--icon-width: 18; --icon-height: 18;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#play-xs" xlink:href="/assets/images/icons.svg?v=1707986906#play-xs"></use></svg>
                    </span>
    </span>

                                            <span class="text--c4">
                                                Видео о проекте
                                            </span>
                                        </a>
                                    </div>
                                    <div>
                                        <a class="btn-container group group--small group--middle group--nowrap" href=" /assets/poklonnaya9_web.pdf?v=1707986906 " data-ajax-page-ignore-prefetch="true" data-ajax-page-ignore="true" target="_blank">
                                                    
                                                                    
            
    <span
        class="btn btn--tetriary btn--outline btn--square btn--sm"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-download-small btn__icon " width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#download-small" xlink:href="/assets/images/icons.svg?v=1707986906#download-small"></use></svg>
                    </span>
    </span>

                                            <span class="text--c4">
                                                Скачать <br />
PDF Брошюру
                                            </span>
                                        </a>
                                    </div>
                                </div>

                                                                                                    
                                <a class="mr-1 text--c4 header-broshure__en" href="/en/signals/iwl.js" data-ajax-page-ignore-prefetch="true" data-ajax-page-ignore="true">
                                                                            EN
                                                                    </a>
                            </div>
                        </div>
                                                    </nav>
        </div>

                                
        <div class="col col--md-3 is-hidden--sm-down p-relative menu-modal__col-2">
            <ul class="menu-modal__images js-menu-background-list"
                                            >
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/3-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/3-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/3-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/3-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/3-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/3-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/5-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/5-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/5-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/5-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/5-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/5-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/6-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/6-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/6-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/6-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/6-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/6-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/7-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/7-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/7-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/7-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/7-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/7-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/1-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/1-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/1-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/1-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/1-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/1-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="js-menu-background menu-modal__image"
                        >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                            </ul>
        </div>
        <div class="col col--md-3 is-hidden--sm-down p-relative menu-modal__col-3">
            <ul class="menu-modal__images js-menu-background-list-reverse"
                                data-reveal-delay="60"
            >
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/3-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/3-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/3-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/3-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/3-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/3-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/3-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/5-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/5-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/5-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/5-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/5-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/5-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/5-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/6-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/6-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/6-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/6-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/6-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/6-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/6-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/7-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/7-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/7-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/7-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/7-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/7-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/7-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/1-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/1-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/1-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/1-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/1-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/1-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/1-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/9-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/9-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/9-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/4-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/4-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/4-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                                    <li
                        class="menu-modal__image "
                    >
                        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js "                data-plugin="appear "        draggable="false"                        data-appear-animation-name="fade-in"    >
                                <source        data-srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22720%22%20height=%22960%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20720%20960%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
            data-src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22480%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20480%22%3E%3C/svg%3E"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" "            draggable="false"                        data-reveal="fade-in"    >
                                <source srcset="/assets/images/menu/2-xxl.webp?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-xxl.jpg?v=1707986906?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/menu/2-md.webp?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
        <img
                                src="/assets/images/menu/2-md.jpg?v=1707986906?v=1707986906"                    alt=""                            width="360" height="480"            draggable="false"
            />
    </picture>

            
        </noscript>
    
                    </li>
                            </ul>
        </div>

        <div class="menu-modal__callback is-hidden--md-up">
                    
                                                                    
            
    <a
        class="btn btn--primary btn--square btn--sm"
                                                href="#callback"
                                                                                                    >
        <span class="btn__content">
                                        <svg class="icon icon-callback-fill btn__icon " width="20" height="20" aria-hidden="true"            viewBox="0 0 20 20"
            style="--icon-width: 20; --icon-height: 20;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#callback-fill" xlink:href="/assets/images/icons.svg?v=1707986906#callback-fill"></use></svg>
                    </span>
    </a>

        </div>
    </div>
                
                
                </div>
                            </div></div>
        </div>
    </div>


                

        
    
    <div
        class="modal ui-dark modal--full is-hidden"
        role="dialog"
        id="favourites"
        aria-hidden="true"        aria-label="избранное"
            
                                    data-plugin="modal favouritesList cardScroll"
                                                        data-modal-auto-close="false"
                                    data-favourites-list-endpoint-method="GET"
                                    data-favourites-list-endpoint="/api/apartments/favourite"
    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close">

                                                                        
                                                                    
            
    <a
        class="btn btn--primary btn--fill-bottom btn--square btn--lg btn--rect modal__close  js-modal-close"
                                                                                                                    aria-label="Закрыть"
                                                    tabindex="0"
                            role="button"
            >
        <span class="btn__content">
                                        <svg class="icon icon-close btn__icon " width="60" height="60" aria-hidden="true"            viewBox="0 0 60 60"
            style="--icon-width: 60; --icon-height: 60;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#close" xlink:href="/assets/images/icons.svg?v=1707986906#close"></use></svg>
                    </span>
    </a>

                    
                                        
    
    <div
        id="favourite-modal-sticky"
        class="js-ajax-list-full"
    >
        <div class="container-h-mob">
            <div class="apartments-intro">
                
                
    
    
    <picture class="is-invisible--js is-hidden--no-js apartments-intro__image"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/apartments/modal/deco-xxxl.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221800%22%20height=%22800%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201800%20800%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-xxxl.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221800%22%20height=%22800%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201800%20800%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-xxl.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221350%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201350%20600%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-xxl.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221350%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201350%20600%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-md.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22900%22%20height=%22400%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20900%20400%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-md.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22900%22%20height=%22400%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20900%20400%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-xs.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22150%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20150%22%3E%3C/svg%3E" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-xs.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22150%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20150%22%3E%3C/svg%3E" type="image/jpeg"/>
        <img
            data-src="/assets/images/apartments/modal/deco-xs.png?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22150%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20150%22%3E%3C/svg%3E"                    alt=""                            width="360" height="150"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" apartments-intro__image"            draggable="false"    >
                                <source srcset="/assets/images/apartments/modal/deco-xxxl.png?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-xxxl.png?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/deco-xxl.png?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-xxl.png?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/deco-md.png?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-md.png?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/deco-xs.png?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-xs.png?v=1707986906" type="image/jpeg"/>
        <img
                                src="/assets/images/apartments/modal/deco-xs.png?v=1707986906"                    alt=""                            width="360" height="150"            draggable="false"
            />
    </picture>

            
        </noscript>
    
            </div>
            <div class="favourites-inner">
                <div class="favourites-inner__head">
                    <div class="favourites-inner__title text--h2-sm">
                        Избранное
                    </div>
                    <div class="favourites-inner__button-group">
                                
                                                                    
                        
    <a
        class="btn btn--tetriary btn--sm btn--outline"
                                    target="_blank" rel="noopener"
                                        href="/apartment/favourites.zip"
                                                                            data-plugin="phonenumber"

                                                    
                                                        data-ajax-page-ignore="true"
                            >
        <span class="btn__content">
                            <span class="btn__text ">Скачать PDF</span>
                                </span>
    </a>

                                
                                                                    
            
    <a
        class="btn btn--tetriary btn--sm btn--outline"
                                                href="#send-pdf"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text ">Отправить на e-mail</span>
                                </span>
    </a>

                    </div>
                </div>
                <div class="favourites-inner__container pb-2 pb-0:md">
                    <div class="favourites-inner__count text--color-small text--crop favourites__subtitle js-ajax-list-counter">
                        <script type="text/template">
                            <%- total %>
                            <%- transchoice(total, [
                                'апартаментов', // 0
                                'апартамент', // 1, 21, ...
                                'апартамента', // 2, 3, 4, 22, 23, ...
                                'апартаментов'  // ...
                            ]) %>
                        </script>
                    </div>
                    <ul class="favourites-inner__list design-modal__list js-card-scroll-container js-ajax-list scrollable-no-hover">
                        <script type="text/template" data-template-variable="apartment">
                            
<% var withFurniture = apartment.withFurniture %>

<li class="
    apartments-list__item 
    apartment-item 
    <% if (withFurniture) { %>ui-orange<% } else { %>ui-light<% } %> 
    ui-background 
    js-card-scroll-item
">
    <a href="<%- apartment.url %>" class="apartment-item__inner" data-ajax-page-ignore-prefetch="true">

        <div class="apartment-item__top">
            <div class="group group--xs">
                <% if (withFurniture) { %>
                    <span class="btn btn--secondary--static btn--xsxl btn--square" 
                        data-plugin="tooltip" 
                        data-tooltip-nowrap="true"
                        title="с мебелью" 
                    >
                        <span class="btn__content">
                            <svg class="icon icon-feature-furniture" width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#feature-furniture" xlink:href="/assets/images/icons.svg?v=1707986906#feature-furniture"></use></svg>
                        </span>
                    </span>
                    <span class="btn btn--secondary--static btn--xsxl btn--square" 
                        data-plugin="tooltip" 
                        data-tooltip-nowrap="true"
                        title="с техникой" 
                    >
                        <span class="btn__content">
                            <svg class="icon icon-feature-appliance" width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#feature-appliance" xlink:href="/assets/images/icons.svg?v=1707986906#feature-appliance"></use></svg>
                        </span>
                    </span>
                <% } %>

                <% each(apartment.features, (feature) => { %>
                    <span class="btn btn--secondary--static btn--xsxl btn--square" 
                        data-plugin="tooltip" 
                        data-tooltip-nowrap="true"
                        title="<%- feature.tooltip %>" 
                    >
                        <span class="btn__content">
                            <svg class="icon icon-<%- feature.icon %>" width="30" height="30" aria-hidden="true"            viewBox="0 0 30 30"
            style="--icon-width: 30; --icon-height: 30;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#<%- feature.icon %>" xlink:href="/assets/images/icons.svg?v=1707986906#<%- feature.icon %>"></use></svg>
                        </span>
                    </span>
                <% }) %>
            </div>

            

        
                                                                    
                        
    <span
        class="btn btn--xs btn--square favourite <%- apartment.isFavourite ? " favourite--active" : "" %>"
                                    data-plugin="favourite"

                                                    
                                                        data-favourite-is-toggle-hide="true"
                                    data-favourite-parent-class-name="apartment-item"
                                    data-favourite-id="<%- apartment.id %>"
                                    data-favourite-method="POST"
                                    data-favourite-url="/api/favorite/toggle.json"
                            >
        <span class="btn__content">
                                        <svg class="icon icon-favourite-small btn__icon " width="32" height="32" aria-hidden="true"            viewBox="0 0 32 32"
            style="--icon-width: 32; --icon-height: 32;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#favourite-small" xlink:href="/assets/images/icons.svg?v=1707986906#favourite-small"></use></svg>
                    </span>
    </span>


        </div>

        <div class="apartment-item__plan">
            
    
    
        
    <img class=" " alt=""
        draggable="false"                
                                    width="160"
                                    height="160"
                                                        safe="true"                src="<%- apartment.plan %>"    />

        
        </div>

        <div class="apartment-item__info">
            <div class="apartment-item__info__top">
                <div class="group group--sm group--column">
                    <span class="text--c4-xs text--color-smallish leading-trim">
                        <% if (withFurniture) { %>
                            с отделкой, </br>
                            мебелью и техникой
                        <% } else { %>
                            с отделкой
                        <% } %>
                    </span>
                    <p class="text--t2-mob leading-trim">
                        <%- numberFormat(apartment.price, 0, '', ' ') %>&nbsp;₽
                    </p>
                </div>

                <p class="text--c3 leading-trim <% if (!withFurniture) { %>text--color-smallish<% } %>">
                    <%- numberFormat(apartment.meterPrice, 0, '', ' ') %>&nbsp;₽&nbsp;/&nbsp;м<sup>2</sup>
                </p>
            </div>
            <div class="apartment-item__info__bottom">
                <div class="group group--column group--none text--c3 leading-trim">
                    <span class="text--c3 text--nowrap">
                        этаж <%- apartment.floor %>
                    </span>
                    <span class="text--c3 text--nowrap">
                        <%- apartment.square %>&nbsp;м<sup>2</sup>
                    </span>
                    <span class="text--c3 text--nowrap">
                        <%- apartment.rooms %> комнаты
                    </span>
                </div>

                <p class="text--h3-mob">
                    <%- apartment.number %>
                </p>
            </div>
        </div>
    </a>
</li>


                        </script>

                        
<li class="favourites-inner__blank apartments-list__item btn-container ui-dark js-card-scroll-item">
    <a href="/apartments" class="apartment-item__inner">
            
                
    
    
    <picture class="is-invisible--js is-hidden--no-js favourites-inner__blank__background"                data-plugin="appear "        draggable="false"    >
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-xxxl.webp?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-xxxl.jpg?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-xxl.webp?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-xxl.jpg?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-lg.webp?v=1707986906" media="(min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-lg.jpg?v=1707986906" media="(min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-md.webp?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-md.jpg?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-xs.webp?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/px-2x1.gif" data-srcset="/assets/images/apartments/modal/blank-xs.jpg?v=1707986906" type="image/jpeg"/>
        <img
            data-src="/assets/images/apartments/modal/blank-xs.jpg?v=1707986906"
                src="/assets/images/px.gif?v=1707986906"                    alt=""                        draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" favourites-inner__blank__background"            draggable="false"    >
                                <source srcset="/assets/images/apartments/modal/blank-xxxl.webp?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/blank-xxxl.jpg?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/blank-xxl.webp?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/blank-xxl.jpg?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/blank-lg.webp?v=1707986906" media="(min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/blank-lg.jpg?v=1707986906" media="(min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/blank-md.webp?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/blank-md.jpg?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/blank-xs.webp?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/blank-xs.jpg?v=1707986906" type="image/jpeg"/>
        <img
                                src="/assets/images/apartments/modal/blank-xs.jpg?v=1707986906"                    alt=""                        draggable="false"
            />
    </picture>

            
        </noscript>
    
                
                                                                    
            
    <span
        class="btn btn--tetriary btn--square btn--outline btn--md-lg favourites-inner__blank__icon"
                                                            >
        <span class="btn__content">
                                        <svg class="icon icon-arrow-right-small btn__icon " width="40" height="40" aria-hidden="true"            viewBox="0 0 40 40"
            style="--icon-width: 40; --icon-height: 40;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#arrow-right-small" xlink:href="/assets/images/icons.svg?v=1707986906#arrow-right-small"></use></svg>
                    </span>
    </span>

        <div class="favourites-inner__blank__text text--c2">
            Выбрать идеальные апартаменты
        </div>
    </a>
</li>                    </ul>
                </div>
            </div>
        </div>
    </div>

        <div class="favourites-empty js-ajax-empty is-hidden">
        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js favourites-empty__image"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-xxxl.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221800%22%20height=%22800%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201800%20800%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-xxxl.jpg?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221800%22%20height=%22800%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201800%20800%22%3E%3C/svg%3E" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-xxl.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221350%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201350%20600%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-xxl.jpg?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%221350%22%20height=%22600%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%201350%20600%22%3E%3C/svg%3E" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-lg.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22900%22%20height=%22400%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20900%20400%22%3E%3C/svg%3E" media="(min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-lg.jpg?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22900%22%20height=%22400%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20900%20400%22%3E%3C/svg%3E" media="(min-width: 980px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-md.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22900%22%20height=%22400%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20900%20400%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-md.jpg?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22900%22%20height=%22400%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20900%20400%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-xs.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22150%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20150%22%3E%3C/svg%3E" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartments/modal/deco-1-xs.jpg?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22150%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20150%22%3E%3C/svg%3E" type="image/jpeg"/>
        <img
            data-src="/assets/images/apartments/modal/deco-1-xs.jpg?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22150%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20150%22%3E%3C/svg%3E"                    alt=""                            width="360" height="150"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" favourites-empty__image"            draggable="false"    >
                                <source srcset="/assets/images/apartments/modal/deco-1-xxxl.webp?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-xxxl.jpg?v=1707986906" media="(min-width: 1920px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-xxl.webp?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-xxl.jpg?v=1707986906" media="(min-width: 1440px) and (min-height: 600px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-lg.webp?v=1707986906" media="(min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-lg.jpg?v=1707986906" media="(min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-md.webp?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-md.jpg?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-xs.webp?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/apartments/modal/deco-1-xs.jpg?v=1707986906" type="image/jpeg"/>
        <img
                                src="/assets/images/apartments/modal/deco-1-xs.jpg?v=1707986906"                    alt=""                            width="360" height="150"            draggable="false"
            />
    </picture>

            
        </noscript>
    
        <div class="container-h-mob pb-2">
            <div class="favourites-inner">
                <div class="row">
                    <div class="col offset--md-2 col--md-4 pt-0.5 pt-1:md">
                        <div class="favourites-inner__title text--h2-sm leading-trim">
                            Избранное
                        </div>
                    </div>
                </div>
                <div class="favourites-inner__container favourites-inner__container--no-border">
                    <div class="row">
                        <div class="col offset--md-2 col--md-4">
                            <div class="h4 text--color-text pt-2 pt-1.5:md pb-1.5 pb-1:md leading-trim">
                                здесь вы сможете найти понравившиеся апартаменты
                            </div>
                                    
                                                                    
            
    <a
        class="btn btn--tetriary btn--sm-md btn--outline"
                                                href="/apartments"
                                                                                                    >
        <span class="btn__content">
                            <span class="btn__text text--c2">Выбрать апартаменты</span>
                                </span>
    </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

                
                
                </div>
                            </div></div>
        </div>
    </div>

                
        
    
    <div
        class="modal ui-dark modal--narrow is-hidden"
        role="dialog"
        id="send-pdf"
        aria-hidden="true"        aria-label="Send PDF form"
            
                                    data-plugin="modal"
    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close">

                                                                        
                                                                    
            
    <a
        class="btn btn--primary btn--fill-bottom btn--square btn--lg btn--rect modal__close  js-modal-close"
                                                                                                                    aria-label="Закрыть"
                                                    tabindex="0"
                            role="button"
            >
        <span class="btn__content">
                                        <svg class="icon icon-close btn__icon " width="60" height="60" aria-hidden="true"            viewBox="0 0 60 60"
            style="--icon-width: 60; --icon-height: 60;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#close" xlink:href="/assets/images/icons.svg?v=1707986906#close"></use></svg>
                    </span>
    </a>

                    
                                        

    <div class="callback">
        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js callback__image"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/apartment/order-deco-md.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22600%22%20height=%22300%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20600%20300%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartment/order-deco-md.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22600%22%20height=%22300%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20600%20300%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartment/order-deco-xs.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22148%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20148%22%3E%3C/svg%3E" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartment/order-deco-xs.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22148%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20148%22%3E%3C/svg%3E" type="image/jpeg"/>
        <img
            data-src="/assets/images/apartment/order-deco-xs.png?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22148%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20148%22%3E%3C/svg%3E"                    alt=""                            width="360" height="148"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" callback__image"            draggable="false"    >
                                <source srcset="/assets/images/apartment/order-deco-md.webp?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/apartment/order-deco-md.png?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartment/order-deco-xs.webp?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/apartment/order-deco-xs.png?v=1707986906" type="image/jpeg"/>
        <img
                                src="/assets/images/apartment/order-deco-xs.png?v=1707986906"                    alt=""                            width="360" height="148"            draggable="false"
            />
    </picture>

            
        </noscript>
    

        <div class="callback__content">

            
<form name="pdf_email" method="post" action="/api/favourite/pdf/mail.json" data-plugin="ajaxForm recaptcha phonenumber trackLead" data-recaptcha2-key="6LfP8K4bAAAAAHMQhn6aW37l3IC6ES-KmbhfQxr_" data-recaptcha3-key="6Ldi8K4bAAAAAPF-RfliJUNMr_iKchAQZm-AmuEg" data-phonenumber-phone-target="action">

        <div class="error-message js-form-error-message is-hidden"></div>

        <div class="js-form-content">
                <div class="form-group">
            <div class="form-control form-control--input form-control--float" data-plugin="inputState">
                <input type="email" id="pdf_email_email" name="pdf_email[email]" required="required" data-msg-email="Пожалуйста, введите действительный адрес электронной почты" data-msg-required="Это поле обязательно к заполнению" placeholder="Ваш E-Mail" />
                <label class="form-label required" for="pdf_email_email">E-mail</label>
            </div>
        </div>

        <div class="form-group form-group--checkbox">
            <label class="form-control form-control-checkbox" for="email-send-agreement">
                <input id="email-send-agreement" name="agreement" type="checkbox" required />
                <span class="form-control-checkbox__icon"></span>
                <span class="form-control-checkbox__label form-control-checkbox__label--width">
                    Принимаю <a href="/privacy-policy" target="_blank">условия</a> обработки персональных данных
                </span>
            </label>
        </div>

        <div class="form-footer">
                    
                                                                    
            
    <button
        class="btn btn--primary btn--primary--light btn--outline btn--text-lg btn--sm-md"
                                    type="submit"
                                                                        >
        <span class="btn__content">
                            <span class="btn__text ">отправить</span>
                                </span>
    </button>

        </div>
    </div>

    <div class="is-hidden js-form-success">
        <p>Проверьте свою почту, мы отправили вам файлы</p>
    </div>
</form>


        </div>
    </div>
                
                
                </div>
                            </div></div>
        </div>
    </div>

                

        
    
    <div
        class="modal ui-dark modal--narrow  is-hidden"
        role="dialog"
        id="callback"
        aria-hidden="true"        aria-label="Заказать
    обратный
    звонок"
            
                                    data-plugin="modal"
    >
        <div class="modal__background"></div>

                <div class="modal__animation">
            <div class="modal__scroller js-scroll-parent"><div class="modal__content-wrapper js-modal-scrollable-content">
                <div class="modal__content js-modal-ignore-auto-close">

                                                                        
                                                                    
            
    <a
        class="btn btn--primary btn--fill-bottom btn--square btn--lg btn--rect modal__close  js-modal-close"
                                                                                                                    aria-label="Закрыть"
                                                    tabindex="0"
                            role="button"
            >
        <span class="btn__content">
                                        <svg class="icon icon-close btn__icon " width="60" height="60" aria-hidden="true"            viewBox="0 0 60 60"
            style="--icon-width: 60; --icon-height: 60;"
        
        ><use href="/assets/images/icons.svg?v=1707986906#close" xlink:href="/assets/images/icons.svg?v=1707986906#close"></use></svg>
                    </span>
    </a>

                    
                                        

    <div class="callback">

        
                
    
    
    <picture class="is-invisible--js is-hidden--no-js callback__image"                data-plugin="appear "        draggable="false"    >
                                <source        data-srcset="/assets/images/apartment/order-deco-md.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22600%22%20height=%22300%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20600%20300%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartment/order-deco-md.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22600%22%20height=%22300%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20600%20300%22%3E%3C/svg%3E" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source        data-srcset="/assets/images/apartment/order-deco-xs.webp?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22148%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20148%22%3E%3C/svg%3E" type="image/webp"/>
                                <source        data-srcset="/assets/images/apartment/order-deco-xs.png?v=1707986906"
        srcset="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22148%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20148%22%3E%3C/svg%3E" type="image/jpeg"/>
        <img
            data-src="/assets/images/apartment/order-deco-xs.png?v=1707986906"
                src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22360%22%20height=%22148%22%20preserveAspectRatio=%22xMinYMax%20meet%22%20viewBox=%220%200%20360%20148%22%3E%3C/svg%3E"                    alt=""                            width="360" height="148"            draggable="false"
            />
    </picture>

                    <noscript>
            
    
    
    
    <picture class=" callback__image"            draggable="false"    >
                                <source srcset="/assets/images/apartment/order-deco-md.webp?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/webp"/>
                                <source srcset="/assets/images/apartment/order-deco-md.png?v=1707986906" media="(min-width: 568px) and (max-aspect-ratio: 13 / 9), only screen and (min-width: 668px) and (min-height: 416px), only screen and (min-width: 980px)" type="image/jpeg"/>
                                <source srcset="/assets/images/apartment/order-deco-xs.webp?v=1707986906" type="image/webp"/>
                                <source srcset="/assets/images/apartment/order-deco-xs.png?v=1707986906" type="image/jpeg"/>
        <img
                                src="/assets/images/apartment/order-deco-xs.png?v=1707986906"                    alt=""                            width="360" height="148"            draggable="false"
            />
    </picture>

            
        </noscript>
    

        <div class="callback__content">
            <p class="text--h2-sm leading-trim">
                Заказать
    обратный
    звонок
            </p>

            
<form name="contact" method="post" action="/api/contact.json" class="callback__form" data-plugin="ajaxForm trackLead recaptcha" data-recaptcha2-key="6LfP8K4bAAAAAHMQhn6aW37l3IC6ES-KmbhfQxr_" data-recaptcha3-key="6Ldi8K4bAAAAAPF-RfliJUNMr_iKchAQZm-AmuEg">

        <div class="error-message js-form-error-message is-hidden"></div>

        <div class="js-form-content">
                <div class="form-group">
            <div class="form-control form-control--input form-control--float" data-plugin="inputState">
                <input type="text" id="contact_name" name="contact[name]" required="required" data-msg-required="Это поле обязательно к заполнению" placeholder="Ваше имя" />
                <label class="form-label required" for="contact_name">Ваше имя</label>
            </div>
        </div>

                <div class="form-group">
            <div class="form-control form-control--input form-control--float" 
                data-plugin="inputState inputMask"
                data-input-mask-mask="+7 ### ### ## ##"
            >
                <input type="tel" id="contact_phone" name="contact[phone]" required="required" data-msg-tel="Пожалуйста, введите действующий телефонный номер" data-msg-required="Пожалуйста, введите действующий телефонный номер" placeholder="Телефон" />
                <label class="form-label required" for="contact_phone">Телефон</label>
            </div>
        </div>

        <div class="form-group form-group--checkbox">
            <label class="form-control form-control-checkbox">
                <input name="agreement" type="checkbox" required/>
                <span class="form-control-checkbox__icon"></span>
                <span class="form-control-checkbox__label form-control-checkbox__label--width">
                    Принимаю <a href="/privacy-policy" target="_blank">условия</a> обработки персональных данных
                </span>
            </label>
        </div>

        <div class="form-footer">
                    
                                                                    
            
    <button
        class="btn btn--primary btn--primary--light btn--outline btn--text-lg btn--sm-md"
                                    type="submit"
                                                                        >
        <span class="btn__content">
                            <span class="btn__text ">оставить заявку</span>
                                </span>
    </button>

        </div>
    </div>

    <div class="is-hidden js-form-success">
        <p class="h2 text--color-text pt-1">Спасибо</p>
        <p>Мы получили ваш запрос и скоро свяжемся с вами!</p>
    </div>
</form>

        </div>
    </div>

                
                
                </div>
                            </div></div>
        </div>
    </div>

                    </div>
    </div>

                        


                
    
<div
    class="preloader  js-preloader is-hidden "
            aria-hidden="true"
    
            data-plugin="preloaderLottie">
    <div class="preloader__content ui-dark ui-background">
        <div class="preloader__content__animation"></div>
    </div>
</div>

                
                    


    
    
<div
    class="preloader preloader--intro js-preloader is-hidden "
            aria-hidden="true"
    
            data-plugin="preloaderIntro"                data-preloader-intro-animation="/assets/lottie/intro/data-summer-ru.json">
    <div class="preloader__content ui-light ui-background">
        <div class="preloader__content__animation"></div>
    </div>
</div>
        
    
                
<div
    class="browser-message ui-dark ui-dark-background"
    aria-hidden="true"
    data-plugin="browserMessage"
    id="browser-message"
>
    <div class="browser-message__deco">
        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="deco"                src="/assets/images/common/deco.jpg?v=1707986906"    />

        
    </div>

    <div class="container-h browser-message__container">
        <div class="row">
            <div class="col col--md-7">
                <p class="h1 browser-message__title leading-trim">вы используете устаревший браузер</p>
            </div>
        </div>
        <div class="row">
            <div class="col col--md-4">
                <p class="text--p2 browser-message__text leading-trim">
                    Cайт может работать в нем некорректно.
                    Мы&nbsp;рекомендуем обновить ваш браузер или использовать последние версии:
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="group group--small browser-message__browsers browser-message__browsers--desktop">
                                        <a href="https://www.google.com/chrome/browser/desktop/" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Chrome"                src="/assets/images/common/outdated-chrome.png?v=1707986906"    />

        
                        <span>Chrome</span>
                    </a>
                    <a href="https://www.mozilla.org/firefox/new/" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Firefox"                src="/assets/images/common/outdated-firefox.png?v=1707986906"    />

        
                        <span>Firefox</span>
                    </a>
                    <a href="https://www.apple.com/osx/" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Safari"                src="/assets/images/common/outdated-safari.png?v=1707986906"    />

        
                        <span>Safari</span>
                    </a>
                    <a href="https://www.microsoft.com/en-us/edge" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Edge"                src="/assets/images/common/outdated-edge.png?v=1707986906"    />

        
                        <span>MS Edge</span>
                    </a>
                </div>
                <div class="group group--small browser-message__browsers browser-message__browsers--ios">
                                        <a href="https://apps.apple.com/us/app/google-chrome/id535886823" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Chrome"                src="/assets/images/common/outdated-chrome.png?v=1707986906"    />

        
                        <span>Chrome</span>
                    </a>
                    <a href="https://apps.apple.com/us/app/firefox-private-safe-browser/id989804926" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Firefox"                src="/assets/images/common/outdated-firefox.png?v=1707986906"    />

        
                        <span>Firefox</span>
                    </a>
                    <a href="https://apps.apple.com/us/app/microsoft-edge/id1288723196" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Edge"                src="/assets/images/common/outdated-edge.png?v=1707986906"    />

        
                        <span>MS Edge</span>
                    </a>
                </div>
                <div class="group group--small browser-message__browsers browser-message__browsers--android">
                                        <a href="https://play.google.com/store/apps/details?id=com.android.chrome" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Chrome"                src="/assets/images/common/outdated-chrome.png?v=1707986906"    />

        
                        <span>Chrome</span>
                    </a>
                    <a href="https://play.google.com/store/apps/details?id=org.mozilla.firefox" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Firefox"                src="/assets/images/common/outdated-firefox.png?v=1707986906"    />

        
                        <span>Firefox</span>
                    </a>
                    <a href="https://play.google.com/store/apps/details?id=com.microsoft.emmx" target="_blank" rel="noopener">
                        
    
    
        
    <img class=" "
        draggable="false"                
                                    alt="Edge"                src="/assets/images/common/outdated-edge.png?v=1707986906"    />

        
                        <span>MS Edge</span>
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col col--md-4 browser-message__close-text">
                <a class="text--c4 leading-trim" href="#"><b>закрыть</b> и продолжить просмотр на свой риск</a>
            </div>
        </div>
    </div>
</div>
    
        <script src="/assets/javascripts/shared.js?v=1707986906" async defer></script>

    <script>
                var INTRO_MODE = 'summer';

                                var LOCALES = {
            'errors': {
                'email': 'Пожалуйста, введите действительный адрес электронной почты',
                'required': 'Это поле обязательно к заполнению',
                'tel': 'Пожалуйста, введите действующий телефонный номер',
                'minlength': 'Пожалуйста, введите не менее {0} символов',

                'generic': 'Ошибка подключения, пожалуйста, попробуйте еще раз',
                'genericCode': 'Произошла ошибка, пожалуйста, попробуйте еще раз',

                // Passwords don't match
                'equalTo': 'Пароль не совпадает'
            }
        };
    </script>

            <script async src="/assets/javascripts/blank.js?v=1707986906" async defer></script>
    </body>
</html>
